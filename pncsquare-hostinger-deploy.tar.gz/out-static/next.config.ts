import { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
      {
        protocol: "http",
        hostname: "**",
      },
    ],
  },

  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: "https://pnc-backend.onrender.com/api/:path*",
      },
    ];
  },
};

export default nextConfig;
//http://localhost:5002/api/v1 ,, https://pnc-backend.onrender.com
