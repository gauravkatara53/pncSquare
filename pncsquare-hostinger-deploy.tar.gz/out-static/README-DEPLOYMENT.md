# PNC Square - Hostinger Deployment Package

This package contains the production-ready build of PNC Square for deployment on Hostinger.

## Deployment Instructions

### Option 1: Node.js Deployment (Recommended)

1. **Upload Files**: Upload the entire `out-static` folder contents to your Hostinger file manager or via FTP
2. **Install Dependencies**: In Hostinger's Node.js manager, run: `npm install`
3. **Set Start Command**: Set the startup command to: `node server.js`
4. **Environment Variables**: 
   - Set `NODE_ENV=production`
   - Set `PORT` to your assigned port (usually 3000 or as provided by Hostinger)
5. **Start Application**: Start the Node.js application

### Option 2: Static File Deployment

If you prefer static file deployment:
1. Upload all files from `out-static` directory to your public_html folder
2. The `index.html` file will redirect users to the main application
3. Make sure your domain points to the correct directory

## Files Included

- `.next/` - Next.js production build
- `public/` - Static assets (images, icons, etc.)
- `server.js` - Express server for Node.js hosting
- `package.json` - Dependencies and scripts for Node.js
- `next.config.ts` - Next.js configuration
- `index.html` - Landing page with navigation

## Features Included

✅ **College Information System**
- College placement data and statistics
- Cutoff information and trends
- Course details and comparisons

✅ **News & Articles**
- News articles with social sharing
- Related articles suggestions
- Mobile-responsive design

✅ **Enhanced Navigation**
- Comprehensive sitemap for SEO
- User-friendly interface
- Mobile share functionality

✅ **API Integration**
- Backend API connectivity
- Real-time data fetching
- Error handling

## Technical Specifications

- **Framework**: Next.js 15.4.6 with React 19
- **Styling**: Tailwind CSS with responsive design
- **Server**: Express.js for Node.js hosting
- **Node Version**: Requires Node.js >= 18.0.0
- **Browser Support**: Modern browsers with ES6+ support

## Support

For deployment issues, contact your Hostinger support team or check the Next.js deployment documentation.

---

**Created**: $(date)  
**Version**: 1.0.0  
**Build**: Production Ready
