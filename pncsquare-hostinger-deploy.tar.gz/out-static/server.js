const express = require('express');
const { createServer } = require('http');
const next = require('next');
const path = require('path');

const dev = process.env.NODE_ENV !== 'production';
const hostname = process.env.HOSTNAME || 'localhost';
const port = process.env.PORT || 3000;

// Create the Next.js app
const app = next({ dev, hostname, port, dir: __dirname });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = express();
  
  // Serve static files from public directory
  server.use(express.static(path.join(__dirname, 'public')));
  
  // Handle all other requests with Next.js
  server.all('*', (req, res) => {
    return handle(req, res);
  });

  // Create HTTP server
  const httpServer = createServer(server);
  
  httpServer.listen(port, (err) => {
    if (err) throw err;
    console.log(`🚀 Server running on http://${hostname}:${port}`);
    console.log(`📁 Serving from: ${__dirname}`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  });
}).catch((ex) => {
  console.error('❌ Error starting server:', ex.stack);
  process.exit(1);
});
